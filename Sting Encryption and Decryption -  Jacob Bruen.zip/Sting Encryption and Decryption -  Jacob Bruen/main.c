#include <stdio.h>
#include <string.h>
// sets encrypt to a string of char
void encrypt(char str[])
{
    int len = 0;
    len = strlen(str);
    for (int i = 0; i < len; i++)
    { 
// only letters are encrypted no spaces will be encryptd, by adding 20 to such characters
        if (str[i] >= 'A' && str[i] <= 'Z')
            str[i] += 20;
        else if (str[i] >= 'a' && str[i] <= 'z')
            str[i] += 20;
    }
    return;
}
//Decryption code for the input given
void decrypt(char str[])
{
    int len = 0;
    len = strlen(str);
    for (int i = 0; i < len; i++)
    {
// this tells the code that a space cannot be decrypted as it was not encrypted.
        if (str[i] != ' ')
            str[i] -= 20;
    }
    return;
}

int main()
{
    char str[100]; 
// lets us assume that the string has maximum length of 100. You can edit this depending on the input length.
    printf("Enter the string: ");
    scanf("%[^\n]s", str); 
  // taken the input from the user

    encrypt(str);
    printf("Encrypted String = %s\n", str); 
  // print the encrypted string
    decrypt(str);
    printf("Decrypted String = %s\n", str); 
  // print the decrypted string
    return 0;
  // ends the code
}