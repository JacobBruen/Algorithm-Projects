String Encryption and Decryption
This program encrypts and decrypts user-provided strings by shifting the alphabetic characters by 20 positions. Spaces and non-alphabetic characters remain unchanged.

Features
Encrypt: Converts a string by shifting each letter by +20 positions.
Decrypt: Reverses the encryption to retrieve the original string.