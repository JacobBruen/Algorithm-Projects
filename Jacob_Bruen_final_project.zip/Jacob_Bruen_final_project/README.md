This project was executed using the Texas Tech University High Performance Computing Center (HPCC). 
Running it independently will not produce output, as it was specifically designed to leverage the 
HPCC’s resources. The objective of this project was to test Python’s multiprocessing capabilities.

The task involved working with multiple matrices composed of "." and "o", representing cell 
states in Conway's Game of Life. The goal was to develop an efficient algorithm capable of 
computing the evolution of a 10,000 x 10,000 matrix within 48 hours, demonstrating both the 
scalability and performance of the implementation.