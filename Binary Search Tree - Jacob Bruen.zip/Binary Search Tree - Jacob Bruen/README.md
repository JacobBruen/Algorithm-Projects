# Binary Search Tree (BST) Program
This program performs key operations on a Binary Search Tree (BST):

Features
Insert: Add nodes to the BST.
Search: Check if a value exists.
Leftmost Node: Find the leftmost node.
Height: Calculate BST height.
Balance Check: Verify if the BST is balanced.

Input/Output
Enter 9 integers to build the BST.
Provide a value to search.
Output includes:
Whether the value exists.
Whether the BST is balanced.
The leftmost node’s value.