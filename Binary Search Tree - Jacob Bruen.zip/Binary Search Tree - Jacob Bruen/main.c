#include <stdio.h>
#include <stdlib.h>
// Structure given to us in the HW
typedef struct treenode {
    int data;
    struct treenode *left;
    struct treenode *right;
} node;

// Function to create a new node with given data
node *Create(int data) {
    node *Node = (node*) malloc(sizeof(node));
    Node->data = data;
    Node->left = NULL;
    Node->right = NULL;
    return Node;
}

// Function to insert a node with given data to BST
node *Put(node *root, int data) {
    if (root == NULL) {
        return Create(data);
    } else if (data < root->data) {
        root->left = Put(root->left, data);
    } else {
        root->right = Put(root->right, data);
    }
    return root;
}


// Function to get the left most node of a BST
// This will return it right away!
node *Left(node *root) {
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

// Function to search for a node with given data in BST
// It mainly just consist of If and Else statements
int Find(node *root, int data) {
    if (root == NULL) {
        return 0;
    } else if (data == root->data) {
        return 1;
    } else if (data < root->data) {
        return Find(root->left, data);
    } else {
        return Find(root->right, data);
    }
}

// Function to get the height of a BST
int Level(node *root) {
    if (root == NULL) {
        return 0;
    }
  // This is the Height or level for BST for Left and Right
    int R_Height = Level(root->right);
    int L_Height = Level(root->left);
    return (L_Height > R_Height) ? L_Height + 1 : R_Height + 1;
}

// Function to check if a BST is balanced or not using Left and Right 
int Balanced(node *root)
{
  if (root == NULL) 
  {
  return 1;
    }
  // This is for the Right and Left levels also known as height
    int R_Level = Level(root->right);
    int L_Level = Level(root->left);
  if (abs(L_Level - R_Level) <= 1 && Balanced(root->left) && Balanced(root->right)) 
  {
  return 1;
    }
      return 0;
}
// Main functions that will check all conditions and print statements
int main() 
{
      node *root = NULL;
      int Numbers[9];
      int Numbers2;
    printf("Enter 9 Integers to insert into the BST:\n");
//Simple for loop to take in "9" numbers from user. (user has to implement 9 if this condition is not met the code will not run!)
  for (int i = 0; i < 9; i++) {
    scanf("%d", &Numbers[i]);
      root = Put(root, Numbers[i]);}
// This is the print statements for all the questions in the HW
  // Balanced, Value to serch, Found or not Found, and Left most node.
    printf("Enter a value to search in the BST: ");
        scanf("%d", &Numbers2);
if (Find(root, Numbers2)) 
 {
    printf("Value %d is found in the BST.\n", Numbers2);
  } 
else 
 {
    printf("Value %d is not found in the BST.\n", Numbers2);
  }
if (Balanced(root)) 
 {
    printf("The BST is balanced.\n");
  } 
else 
 {
    printf("The BST is not balanced.\n");
  }
node *leftMostNode = Left(root);
    printf("The left most node of the BST is: %d\n", leftMostNode->data);   
return 0;
}