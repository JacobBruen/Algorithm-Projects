# Hybrid Merge-Insertion Sort
This program implements a hybrid sorting algorithm that combines Merge Sort and Insertion Sort for efficient array sorting.

Features
Insertion Sort: Used for small subarrays for simplicity and efficiency.
Merge Sort: Applied to larger subarrays using a divide-and-conquer approach.
Hybrid Approach: Switches to Insertion Sort for subarrays of size ≤ k (threshold).

How It Works
insertionSort: Sorts subarrays using Insertion Sort.
mergeSort: Recursively sorts subarrays, switching to Insertion Sort when subarray size ≤ k.

Example Usage
Input Array:
39 9 81 45 90 27 72 18
Sorted Array:
9 18 27 39 45 72 81 90

Customization
Modify the array in the main function.
Adjust k to set the Insertion Sort threshold.

Run Instructions
Compile:
bash
Copy code
gcc hybrid_sort.c -o hybrid_sort
Execute:
bash
Copy code
./hybrid_sort