//Include Librarys
#include <stdio.h>

// This is the sort function for an insersion sort
  void insertionSort(int arr[], int n) {
  int i, key, j;
// This is a for loop that starts from the second element
// This will store the element that it is on and initilize j to decrease
for (i = 1; i < n; i++) {
      key = arr[i];
      j = i - 1; 

// Move one element ahead of the other element i nthe arrat based on size
while (j >= 0 && arr[j] > key) {
      arr[j + 1] = arr[j];
      j = j - 1;
    }
// Places the element into the correct position
    arr[j + 1] = key;
  }
}

// This is the Merge sort function
// Checks "l" and "r" and determins if l is smaller or larger
void mergeSort(int arr[], int l, int r, int k) {
    if (l < r) { 
        // Checks the size of the subarray is less than or equal to k then uses insersion sort
if (r - l + 1 <= k) {
  insertionSort(arr + l, r - l + 1);
  } 
// If else than use merge sort to sort the array 
else { 
// Locate the middle of the array 
  int m = l + (r - l) / 2; 
            
// Recursively sort the left and right subarrays
  mergeSort(arr, l, m, k);
  mergeSort(arr, m + 1, r, k);
    int i, j, k;
            
  // Size of the left subarray
    int a1 = m - l + 1; 

  // Size of the right subarray
    int a2 = r - m;

  // Store the subarrays into new arrays (Temp Arrays)
    int Left[a1], Right[a2]; 
            
  // Copy the left subarray into the temporary array Left
  for (i = 0; i < a1; i++)
      Left[i] = arr[l + i];
  // Copy the right subarray into the temporary array R
  for (j = 0; j < a2; j++)
      Right[j] = arr[m + 1 + j];
  // Set the indexes (Left, Middle, Right)
  i = 0; 
 j = 0; 
k = l; 
            
// Add the left and right subarrays into the original then sort in assending order
  while (i < a1 && j < a2) {
    if (Left[i] <= Right[j]) {
      arr[k] = Left[i];
      i++;
      } 
    else {
      arr[k] = Right[j];
      j++;
      }
      k++;
    }
// Copy the remaining elements of "Left"
  while (i < a1) {
      arr[k] = Left[i];
      i++;
      k++;
      }
// Copy the remaining elements of "Right"
  while (j < a2) {
      arr[k] = Right[j];
      j++;
      k++;
      }
    }
  }
}

// Set up the test array and the print functions
int main() {
    int arr[] = {39, 9, 81, 45, 90, 27, 72, 18}; // Input array
    int n = sizeof(arr) / sizeof(arr[0]); 
int k = 4;

// Print array
printf("Array:\n");
for (int i = 0; i < n; i++) {
    printf("%d ", arr[i]);
}
printf("\n");

// sort the arrays using Merge sort with "K=4"
mergeSort(arr, 0, n - 1, k); 

// Print the sorted array
printf("Sorted Array:\n");
for (int i = 0; i < n; i++) {
    printf("%d ", arr[i]); 
}
printf("\n");

return 0;
}