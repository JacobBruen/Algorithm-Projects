package com.csproject.character.effects;

public class NoEffect extends StatusEffect {
    public NoEffect() {
        super(1);
    }
}
