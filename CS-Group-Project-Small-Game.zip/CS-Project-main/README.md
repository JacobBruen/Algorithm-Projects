# CS-2365-001 Object-Oriented Programming Final Project
#### Game Character Creation System

## Group Members
* Cameron Averett
* Jacob Bruen
* William Paroff

## IDE

The following IDEs were used for developing this project.
* IntelliJ CE
* Eclipse

## Java Version

This project was developed with Java 17 and should be run in the same version.

## Operating System

The following operating systems were tested for this project to be run in.
* Windows 11
* MacOS Monterey

## Running Project

The entry point for this project is the Java class com.csproject.Main.
As stated before, this project was meant to be run in Java 17 and no program arguments are not required.

### IntelliJ CE Running

After opening IntelliJ, click open at the top and navigate to the project directory.
Once the project is open, navigate to the Main class and click the green arrow next to the main method.

