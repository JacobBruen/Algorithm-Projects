// Including the Studios that we need to complete the program.
#include <stdio.h>
#include<stdlib.h>
  typedef struct listnode
{    // Basic node structure.
  int data;
    struct listnode *next;
  }
  node;  // we will use multiple nodes in this program.

//Finding the Middle node and returning it, if there are two or more itll taker the furthest to the right.
node* findMiddle_node(node *head){
node *slow=head,*fast=head;
// there are two types of node pointers a slow and fast one, the slow one wil move one at a time and the fast one will go two at a time. This means that hte slow one will reach the end slower thatns the fast one by a factor of 2.
  
if(head==NULL)return NULL;
  while(slow!=NULL && fast !=NULL && fast->next !=NULL)
{
    slow=slow->next;
  fast=fast->next->next;
}
  return slow;  // Since the slow node is only in the middle itll return the spot that the slow node is at when the fast one reaches the end of the list.
}
  int main()
{

  node *head = NULL,*tail=NULL; // Test the code above and create a linked list in the prosess. 
// entering a linked list and when the user implements 0 and enters the code will terminate and give an output.
  printf("Enter list data:(0 to stop)");
  int n;
    do{
      scanf("%d",&n);  // Will scan the user input iff == 0 then the code will terminate and give output.
    if(n==0)break;
      node *temp1 = (node*)malloc(sizeof(node)); // Creating the node  using the malloc command in c.
temp1->data=n;   // Assigning a certian value int the data.
temp1->next=NULL;
    if(head==NULL)   // Inserts the node.
      head=tail=temp1;
        else
      {
    tail->next=temp1;
  tail=temp1;
}

}while(1);
  node *temp=head;
    printf("Linkedlist :");    // Prints the linked lis that was given by user and the middle nodes.
  while(temp!=NULL)
{
    printf("%d ",temp->data);
  temp=temp->next;
}
  printf("\n");
    node *mid = findMiddle_node(head);   // This method will call the slow head to determine the center of the list and print out the output.
  printf("Middle node is :%d\n",mid->data);
      return 0;      // Finally the middle heads value will be printed out completing the code and ending the program.
}