Features
Dynamic Linked List Creation: Users can input numbers to create a linked list. Enter 0 to stop.
Find Middle Node: Determines the middle node using a two-pointer technique (slow and fast pointers).
How to Run
Compile:
bash
Copy code
gcc find_middle_node.c -o find_middle_node  
Run:
bash
Copy code
./find_middle_node  
Input/Output Example
Input:

plaintext
Copy code
Enter list data: (0 to stop)  
1 2 3 4 5 0  
Output:

plaintext
Copy code
Linkedlist: 1 2 3 4 5  
Middle node is: 3  