#include <stdio.h>

// this function will calculate transpose
void trans(int row,int col,int a[row][col],int transpose[row][col]) 
{
  // Adds to the Row and the Column 
    for (int i = 0; i < row; ++i)
       for (int j = 0; j < col; ++j) {
             transpose[j][i] = a[i][j];
           }
}

// function for printing Arrays
void print(int row,int col,int transpose[row][col])
{
  // Adds to the columns 
   for (int i = 0; i < col; ++i)
     // Adds to the rows
      for (int j = 0; j < row; ++j) {
          printf("%d  ", transpose[i][j]);
          if (j == row - 1)
            printf("\n");
  }
}

//main function 
int main() 
{
   system("CLS");
  //Declaring the row and column
  int row, col; 
  printf("Enter rows and columns:\n");
  scanf("%d %d", &row, &col); // taking row and column
  int a[row][col], transpose[row][col]; 
 // initializing Arrays for matrix
 // Takes the matrix Data from the user
  printf("\nEnter matrix elements:\n");
  for (int i = 0; i < row; ++i) 
  for (int j = 0; j < col; ++j) {
  // Takes the elements from the user
    printf("Enter element a%d%d: ", i + 1, j + 1);
    scanf("%d", &a[i][j]);
  }

   printf("\nEntered matrix: \n");
   print(row, col,a); 
  // function call to print matrix before transpose
   trans(row,col,a,transpose); 
  // function call to calculate transpose
   printf("\nTranspose of the matrix:\n");
  // Prints the transport matrix
   print(row, col,transpose); 
   return 0;
  // Ends the code
}