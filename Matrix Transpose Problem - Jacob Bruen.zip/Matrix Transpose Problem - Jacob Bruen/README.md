# Matrix Transpose Program
This program calculates and displays the transpose of a user-defined matrix.

Features
Input Matrix: User provides the dimensions and elements of the matrix.
Matrix Transpose: Computes and displays the transpose of the matrix.

How to Run
Compile:
bash
gcc matrix_transpose.c -o matrix_transpose  
Run:
bash
./matrix_transpose  

Example Input/Output
Input:
Enter rows and columns:  
2 3  
Enter matrix elements:  
Enter element a11: 1  
Enter element a12: 2  
Enter element a13: 3  
Enter element a21: 4  
Enter element a22: 5  
Enter element a23: 6  
Output:
Entered matrix:  
1  2  3  
4  5  6  

Transpose of the matrix:  
1  4  
2  5  
3  6  